import tensorflow as tf


class MyDenseLayer(tf.keras.layers.Layer):
    def __init__(self, num_outputs, activation=None):
        super(MyDenseLayer, self).__init__()
        self.num_outputs = num_outputs
        self.activation = lambda x: x # YOUR CODE HERE

    def build(self, input_shape):
        """Creates the variables (i.e., weights) of the layer"""
        self.kernel = None # YOUR CODE HERE

    @tf.function
    def call(self, inputs):
        """Perform layer computations"""
        return self.activation(tf.matmul(inputs, self.kernel))


layer = MyDenseLayer(10)
