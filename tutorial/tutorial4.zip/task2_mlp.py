#!/usr/bin/env python
import numpy as np
import tensorflow as tf
from task4_layer import MyDenseLayer


def read_dataset(filename):
    """Reads a dataset from the specified path and returns input vectors and labels in an array of shape (n, 101)."""
    with open(filename, "r") as f:
        lines = f.readlines()
        dims = len(lines[0].split("\t")[-1].split())
        # preallocate memory for the data
        data = np.empty((len(lines), dims), dtype=float)
        labels = np.empty((len(lines), 1), dtype=int)

        for i, line in enumerate(lines):
            _, str_label, str_vec = line.split("\t")
            labels[i] = int(str_label.split("=")[1] == "POS")
            data[i] = [float(f) for f in str_vec.split()]
    return data, labels


class MyMLP(tf.keras.Model):
    def __init__(self, input_dims, output_activation, loss_func):
        super(MyMLP, self).__init__()
        self.hidden_layers = tf.keras.models.Sequential()
        self.hidden_layers.add(tf.keras.Input(shape=(input_dims,)))
        # HIDDEN LAYERS HERE

        self.output_layer = tf.keras.layers.Dense(
            1, activation=output_activation, use_bias=False
        )

        # metrics for monitoring training
        self.mean_loss = tf.keras.metrics.Mean(name="train_loss")
        self.accuracy = tf.keras.metrics.BinaryAccuracy(name="train_accuracy")

        self.loss_func = loss_func()

    @tf.function
    def call(self, x):
        return self.output_layer(self.hidden_layers(x))

    def train(self, embeddings, labels, epochs, optimizer, learning_rate, batch_size):
        """
        Trains the model for a fixed number of epochs (iterations on a
        dataset). Tensorflow already provides builtin functionality for this
        (https://www.tensorflow.org/api_docs/python/tf/keras/Model#fit), but
        here we do it the manual way.
        """

        dataset = (
            tf.data.Dataset.from_tensor_slices((embeddings, labels))
            .shuffle(len(labels))
            .batch(batch_size)
        )
        optimizer = optimizer(learning_rate=learning_rate)

        for epoch in range(1, epochs + 1):
            # Reset the metrics at the start of the next epoch
            self.mean_loss.reset_states()
            self.accuracy.reset_states()

            for batch_x, batch_y in dataset:
                with tf.GradientTape() as tape:
                    predictions = self(batch_x, training=True)
                    loss = self.loss_func(batch_y, predictions)
                gradients = tape.gradient(loss, self.trainable_variables)
                optimizer.apply_gradients(zip(gradients, self.trainable_variables))

                self.mean_loss(loss)
                self.accuracy(batch_y, predictions)
            print(
                f"Epoch {epoch}, "
                f"Train Loss: {self.mean_loss.result()}, "
                f"Train Accuracy: {self.accuracy.result() * 100}%"
            )

    def eval(self, embeddings, labels):
        # EVALUATION HERE
        return 0, 0


if __name__ == "__main__":
    train_x, train_y = read_dataset("datasets/rt-polarity.train.vecs")
    dev_x, dev_y = read_dataset("datasets/rt-polarity.dev.vecs")
    test_x, test_y = read_dataset("datasets/rt-polarity.test.vecs")
    mlp = MyMLP(
        train_x.shape[1],
        None, # ACTIVATION HERE
        tf.keras.losses.MeanSquaredError,
    )

    dev_loss, dev_acc = mlp.eval(test_x, test_y)
    print("Before training:", f"Dev Loss: {dev_loss}, Dev Acc: {dev_acc}")
    mlp.train(train_x, train_y, 10, tf.keras.optimizers.SGD, 0.01, 10)
    dev_loss, dev_acc = mlp.eval(test_x, test_y)
    print("After training:", f"Dev Loss: {dev_loss}, Dev Acc: {dev_acc}")
