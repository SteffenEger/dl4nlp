#!/usr/bin/env python
import sys
import numpy as np
from random import choices

# read text and count ngrams
def read_text(fn):
    uni, bi, tri = {}, {}, {}
    for line in open(fn):
        line = line.strip()
        lstOfWords = ["SOS1", "SOS2"] + line.split()
        for iw, w in enumerate(lstOfWords):
            if w not in ["SOS1", "SOS2"]:
                uni[w] = uni.get(w, 0) + 1
            if iw > 0:
                prev = lstOfWords[iw - 1]
                if prev not in bi:
                    bi[prev] = {}
                bi[prev][w] = bi[prev].get(w, 0) + 1
                if iw > 1:
                    pprev = lstOfWords[iw - 2]
                    # tri[(w,prev,pprev)] = tri.get((w,prev,pprev),0)+1
                    if pprev not in tri:
                        tri[pprev] = {}
                    if prev not in tri[pprev]:
                        tri[pprev][prev] = {}  # {prev:{}}
                    tri[pprev][prev][w] = tri[pprev][prev].get(w, 0) + 1
                    # if pprev=="SOS2": print(tri[pprev])
    return uni, bi, tri


def generate_uni(uni, seqLen=10):
    # n = len(ngram.keys()[0])
    s = sum(uni.values())
    words = sorted(uni.keys())
    uni_norm = [uni[u] / s for u in words]
    for i in range(seqLen):
        # print(words,uni_norm)
        w = choices(words, uni_norm)[0]  # np.random.choice(words,uni_norm)
        print(w, end=" ")
    print()


def normalize(bi):
    bi_norm = {}
    for prev in bi:
        dist = bi[prev]
        s = sum(dist.values())
        bi_norm[prev] = {}
        for w in dist:
            bi_norm[prev][w] = dist[w] / s
    return bi_norm


def normalize_tri(tri):
    tri_norm = {}
    for pprev in tri:
        next = tri[pprev]
        tri_norm[pprev] = {}
        for prev in next:
            dist = tri[pprev][prev]
            s = sum(dist.values())
            tri_norm[pprev][prev] = {}
            for w in dist:
                tri_norm[pprev][prev][w] = dist[w] / s
    return tri_norm


def generate_bi(bi_norm, seqLen=10):
    for i in range(seqLen):
        if i == 0:
            w = "SOS2"
            continue
        # elif i>0:
        #  pass
        try:
            dist = bi_norm[w]
        except KeyError:
            # we terminate
            break
        words = list(dist.keys())
        vals = [dist[v] for v in words]
        # YOUR CODE HERE
        w = words[0]
        print(w, end=" ")
    print()


def generate_tri(tri_norm, seqLen=10):
    for i in range(seqLen):
        if i == 0:
            w1 = "SOS1"
            continue
        elif i == 1:
            w2 = "SOS2"
            # continue
        # print("|",w1,w2,"#")
        try:
            dist = tri_norm[w1][w2]
        except KeyError:
            # we terminate
            print("END")  # tri_norm[w1])
            break
        words = list(dist.keys())
        vals = [dist[v] for v in words]
        w = choices(words, vals)[0]  # np.random.choice(words,uni_norm)
        print(w, end=" ")
        w1, w2 = w2, w
    print()


if __name__ == "__main__":
    for corpus in ("datasets/shakespeare.txt", "datasets/mobydick.txt"):
        print(f"Corpus {corpus}:")
        uni, bi, tri = read_text(corpus)
        # print(uni)
        # print(choices(["a",1,2],[0.25,0.5,0.25]))
        generate_uni(uni, 10)
        bi_norm = normalize(bi)
        tri_norm = normalize_tri(tri)
        generate_bi(bi_norm, 10)
        # print(tri_norm)
        # print(tri_norm["SOS2"])
        generate_tri(tri_norm, 10)
