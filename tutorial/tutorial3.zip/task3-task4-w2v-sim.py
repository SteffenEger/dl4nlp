#!/usr/bin/env python
from gensim.models.keyedvectors import KeyedVectors
import numpy as np


def load_ws353_dataset(path):
    with open(path, "r") as file:
        # skip the first line
        file = iter(file)
        next(file)

        word_pairs = []
        gold_labels = []
        for line in file:
            w1, w2, human = line.split("\t")
            word_pairs.append((w1, w2))
            gold_labels.append(float(human))
    return word_pairs, gold_labels


def load_embeddings(path):
    # (3.i) YOUR CODE HERE
    raise NotImplementedError


def compute_similarities(word_pairs, word_vectors):
    # (3.ii) YOUR CODE HERE
    raise NotImplementedError


def compute_spearman(gold_labels, prediction):
    # (3.iii) YOUR CODE HERE
    raise NotImplementedError


def compute_bias(biased_pairs, word_vectors):
    bias = 0
    for pair in biased_pairs:
        male, female, occupation = pair
        # (4.i) YOUR CODE HERE
    return bias


## Bonus
# ------------------------------------------------------------------------------


def compute_bias_vector(word_vectors):
    debias_pairs = [
        ("man", "woman"),
        ("son", "daughter"),
        ("he", "she"),
        ("his", "her"),
        ("male", "female"),
        ("boy", "girl"),
        ("himself", "herself"),
        ("guy", "gal"),
        ("father", "mother"),
    ]

    embeddings1 = np.stack([word_vectors[word] for word, _ in debias_pairs], 0)
    embeddings2 = np.stack([word_vectors[word] for _, word in debias_pairs], 0)

    *_, v = np.linalg.svd(embeddings1 - embeddings2)
    v_b = v[0]
    return v_b


def attentuate_bias(biased_pairs, word_vectors):
    bias_vector = compute_bias_vector(word_vectors) # v_b in formula
    debiased_vectors = KeyedVectors(vector_size=word_vectors.vector_size)

    for word in {word for words in biased_pairs for word in words}:
        embedding = word_vectors[word]
        # Bonus: YOUR CODE HERE
        debiased_embedding = embedding
        debiased_vectors[word] = debiased_embedding

    return compute_bias(biased_pairs, debiased_vectors)


# ------------------------------------------------------------------------------

if __name__ == "__main__":
    word_pairs, gold_labels = load_ws353_dataset("datasets/wordsim353.txt")
    embeddings = load_embeddings("word2vec-google-news-300")
    predictions = compute_similarities(word_pairs, embeddings)
    print("Spearman's r:", compute_spearman(gold_labels, predictions))
    print(
        "Gender bias:",
        compute_bias(
            [("he", "she", "boss"), ("he", "she", "receptionist")], embeddings
        ),
    )
    print(
        "Attentuated gender bias:",
        attentuate_bias(
            [("he", "she", "boss"), ("he", "she", "receptionist")], embeddings
        ),
    )
