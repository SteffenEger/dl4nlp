#!/usr/bin/env python
from gensim.models import Word2Vec


def read_dataset(path):
    sentences = []
    with open(path, "rb") as f:
        for line in f:
            sentences.append(line.decode().split())
    return sentences


def train_model(sentences):
    model = Word2Vec()
    # YOUR CODE HERE
    return model


if __name__ == "__main__":
    sentences = read_dataset("datasets/spongebob-transcript.txt")
    model = train_model(sentences)
    print(model.wv.most_similar("pineapple", topn=10))
