#!/usr/bin/env python

from transformers import TFBertModel
from sentence_transformers import SentenceTransformer

# optional: download all models we might need before the tutorial
for model in ['bert-base-cased']:
    TFBertModel.from_pretrained(model)
for model in ["bert-base-nli-mean-tokens", "xlm-r-bert-base-nli-stsb-mean-tokens"]:
    SentenceTransformer(model)
