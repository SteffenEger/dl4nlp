#!/usr/bin/env python
import numpy as np

from task2_power_sbert import sbert_embed
from random import shuffle

# Corpus with example sentences
corpus = [
    "A man is eating a piece of bread.",
    "The girl is carrying a baby.",
    "A cheetah is running behind its prey.",
    "A woman is riding a horse.",
    "The baby is carried by the woman",
    "Someone in a T-rex costume is playing a set of drums.",
    "A woman is riding a white horse on an enclosed ground.",
    "A man is eating food.",
    "A dinosaur is playing drums.",
    "A man is eating pasta.",
    "A cheetah chases prey on across a field.",
]


class Point:
    def __init__(self, text, cluster):
        self.text = text
        self.vector = sbert_embed(text)
        self.cluster = cluster


class KMeans:
    def __init__(self, texts, n_clusters):
        shuffle(texts)
        self.n_clusters = n_clusters
        self.points = [Point(text, idx % n_clusters) for idx, text in enumerate(texts)]

    def get_cluster_points(self, cluster):
        # YOUR CODE HERE (a)
        raise NotImplementedError

    def get_cluster_means(self):
        # YOUR CODE HERE (b)
        raise NotImplementedError

    def update_clusters(self):
        # YOUR CODE HERE (c)
        raise NotImplementedError

    def fit(self, iterations=3000):
        for _ in range(iterations):
            self.update_clusters()


if __name__ == "__main__":
    num_clusters = 5
    clustering_model = KMeans(corpus, num_clusters)
    clustering_model.fit()

    for cluster in range(num_clusters):
        print("Cluster: ", cluster + 1)
        print(*[p.text for p in clustering_model.get_cluster_points(cluster)], sep="\n")
