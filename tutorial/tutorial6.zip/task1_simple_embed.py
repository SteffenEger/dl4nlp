#!/usr/bin/env python

from datasets import load_dataset
from transformers import BertTokenizer, TFBertModel
import numpy as np
import tensorflow as tf
from tensorflow.keras.losses import cosine_similarity as neg_cosine_similarity
from scipy.stats import spearmanr

bert = TFBertModel.from_pretrained("bert-base-cased")
tokenizer = BertTokenizer.from_pretrained("bert-base-cased")

def cls_embed(sentences, batch_size=16):
    cls_embeddings = np.empty((len(sentences), bert.config.hidden_size))
    for i in range(0, len(sentences), batch_size):
        inputs = tokenizer(
            sentences[i : i + batch_size],
            padding=True,
            truncation=True,
            return_tensors="tf",
        )
        embeddings = bert(**inputs).last_hidden_state
        # YOUR CODE HERE (a)
    return cls_embeddings


def mean_embed(sentences, batch_size=16):
    mean_embeddings = np.empty((len(sentences), bert.config.hidden_size))
    for i in range(0, len(sentences), batch_size):
        inputs = tokenizer(
            sentences[i : i + batch_size],
            padding=True,
            truncation=True,
            return_tensors="tf",
        )
        embeddings = bert(**inputs).last_hidden_state
        mask = inputs["attention_mask"]
        # YOUR CODE HERE (b)
    return mean_embeddings


if __name__ == "__main__":
    dataset = load_dataset("stsb_multi_mt", name="en", split="dev[:200]")
    cls_similarities = -neg_cosine_similarity(
        cls_embed(dataset["sentence1"]), cls_embed(dataset["sentence2"])
    )
    print(
        "Spearman's rho with [CLS] embeddings:",
        spearmanr(cls_similarities, dataset["similarity_score"])[0],
    )
    mean_similarities = -neg_cosine_similarity(
        mean_embed(dataset["sentence1"]), mean_embed(dataset["sentence2"])
    )
    print(
        "Spearman's rho with mean embeddings:",
        spearmanr(mean_similarities, dataset["similarity_score"])[0],
    )
