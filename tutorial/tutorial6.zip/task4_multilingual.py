#!/usr/bin/env python
from sentence_transformers import SentenceTransformer
import tensorflow as tf

multi_sbert = SentenceTransformer("xlm-r-bert-base-nli-stsb-mean-tokens")

# Two lists of sentences
sentences1 = ['The cat sits outside',
             'A man is playing guitar',
             'The new movie is awesome']

sentences2 = ['Der Hund spielt im Garten',
              'Eine Frau liest ein Buch',
              'Der neue Film ist so toll']

def cos_sim(a, b):
    """
    Embed a & b and compute the cosine similarity cos_sim(a[i], b[j]) for all i and j.
    :return: Matrix with res[i][j]  = cos_sim(a[i], b[j])
    """

    # YOUR CODE HERE
    raise NotImplementedError

#Compute embedding for both lists

#Compute cosine-similarits
cosine_scores = cos_sim(sentences1, sentences2)

#Output the pairs with their score
for i in range(len(sentences1)):
    for j in range(len(sentences2)):
        print("{} \t\t {} \t\t Score: {:.4f}".format(sentences1[i], sentences2[j], cosine_scores[i][j]))
