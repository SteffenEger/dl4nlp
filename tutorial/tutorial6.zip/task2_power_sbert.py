#!/usr/bin/env python

from datasets import load_dataset
import numpy as np
from scipy.stats import spearmanr
from sentence_transformers import SentenceTransformer
import tensorflow as tf
from tensorflow.keras.losses import cosine_similarity as neg_cosine_similarity
from transformers import BertTokenizer, TFBertModel

bert = TFBertModel.from_pretrained("bert-base-cased")
tokenizer = BertTokenizer.from_pretrained("bert-base-cased")
sbert = SentenceTransformer("bert-base-nli-mean-tokens")


def power_mean_embed(sentences, batch_size=16, mode="mean"):
    reduced_embeddings = np.empty((len(sentences), bert.config.hidden_size))
    for i in range(0, len(sentences), batch_size):
        inputs = tokenizer(
            sentences[i : i + batch_size],
            padding=True,
            truncation=True,
            return_tensors="tf",
        )
        embeddings = bert(**inputs).last_hidden_state
        mask = inputs["attention_mask"]
        # YOUR CODE HERE
    return reduced_embeddings


def sbert_embed(sentences, batch_size=16):
    # Placeholder you can remove this
    embeddings = np.empty((len(sentences), sbert._first_module().auto_model.config.hidden_size))
    # YOUR CODE HERE
    return embeddings


if __name__ == "__main__":
    dataset = load_dataset("stsb_multi_mt", name="en", split="dev[:200]")
    src_embeddings = tf.concat(
        [
            power_mean_embed(dataset["sentence1"], mode="min"),
            power_mean_embed(dataset["sentence1"], mode="mean"),
            power_mean_embed(dataset["sentence1"], mode="max"),
        ],
        axis=1,
    )
    tgt_embeddings = tf.concat(
        [
            power_mean_embed(dataset["sentence2"], mode="min"),
            power_mean_embed(dataset["sentence2"], mode="mean"),
            power_mean_embed(dataset["sentence2"], mode="max"),
        ],
        axis=1,
    )
    power_mean_similarities = -neg_cosine_similarity(src_embeddings, tgt_embeddings)
    print(
        "Spearman's rho with power mean embeddings:",
        spearmanr(power_mean_similarities, dataset["similarity_score"])[0],
    )
    sbert_similarities = -neg_cosine_similarity(
        sbert_embed(dataset["sentence1"]), sbert_embed(dataset["sentence2"])
    )
    print(
        "Spearman's rho with SBERT embeddings:",
        spearmanr(sbert_similarities, dataset["similarity_score"])[0],
    )
