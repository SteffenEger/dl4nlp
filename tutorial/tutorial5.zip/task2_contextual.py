#!/usr/bin/env python

from transformers import BertTokenizer, TFBertModel
from tensorflow.keras.losses import cosine_similarity
import tensorflow as tf

def embed(text):
    model = TFBertModel.from_pretrained('bert-base-cased')
    tokenizer = BertTokenizer.from_pretrained('bert-base-cased')

    # add BERT special tokens and tokenize
    marked_text = f"[CLS] {text} [SEP]"
    tokenized_text = tokenizer.tokenize(marked_text)

    # map token strings to vocabulary indeces
    input_ids = tokenizer.convert_tokens_to_ids(tokenized_text)
    token_type_ids = [1] * len(tokenized_text)

    # convert inputs to tensors
    input_id_tensors = tf.constant([input_ids])
    token_type_tensors = tf.constant([token_type_ids])

    # get BERT representations from last hidden layer
    outputs = model(input_id_tensors, token_type_tensors)
    return tokenized_text, outputs.last_hidden_state

def compare_homonyms(tokens, embeddings):
    bank_indexes = [idx for idx, subword in enumerate(tokens) if subword == "bank"]
    # YOUR CODE HERE


if __name__ == "__main__":
    # sentence with multiple meanings of the word bank
    text = "After stealing money from the bank vault, the bank robber was seen fishing on the Mississippi river bank."
    tokenized, embeddings = embed(text)

    print("Tokens:", tokenized)
    compare_homonyms(tokenized, embeddings)
